package com.eazybytes.message2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Message2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
