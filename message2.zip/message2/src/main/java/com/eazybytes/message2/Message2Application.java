package com.eazybytes.message2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Message2Application {

	public static void main(String[] args) {
		SpringApplication.run(Message2Application.class, args);
	}

}
